# Bàn giao demo UI văn phòng AI
Bản bàn giao: 10/10/2026. Frontend trình diễn độc lập, chưa nối backend.

## Chạy
Giải nén rồi mở index.html bằng Chrome/Edge hiện đại. Không cần cài dependency, tài khoản, database hoặc API key. Avatar SVG được nhúng sẵn.

Nếu muốn chạy qua localhost, mở terminal tại thư mục giải nén và chọn MỘT lệnh:
- Có Bun: bun server.ts
- Có Python: python -m http.server 3130 --bind 127.0.0.1

Mở http://127.0.0.1:3130/; Ctrl+C để dừng server. Nếu cổng bận, đổi cổng trong server.ts hoặc lệnh Python.

## Chức năng
- Văn phòng 4 chỗ ngồi: Minh Anh (Ban quản lý), Agent Điều phối, Agent Kỹ thuật, Agent Lễ tân. Đây là 1 người và 3 agent.
- Avatar 2D trong suốt, bàn và máy tính vẽ bằng SVG/CSS; giao diện claymorphism, responsive.
- Xem thảo luận: kịch bản 7 lượt; animation suy nghĩ/gõ và gửi tin. Có Dừng, Xem lại; mỗi lượt xem lại tạo hội thoại mới.
- Mỗi chỗ ngồi hiện tin nhắn gần nhất; popup Tin nhắn chứa toàn bộ lịch sử hội thoại đang chọn. Đóng popup không dừng kịch bản.
- Tìm/chọn/tạo hội thoại, gửi tin và phản hồi giả lập. Enter gửi, Shift+Enter xuống dòng.
- Hỗ trợ giảm chuyển động theo cài đặt hệ điều hành.

## File và nơi sửa
- index.html: toàn bộ HTML/CSS/JavaScript, không dùng framework.
- server.ts: server Bun tối giản phục vụ trang.
- Tìm members, portraits, avatar(): tên/vai trò/nhân vật SVG.
- Tìm rooms: hội thoại ban đầu.
- Tìm discussionSteps: nội dung kịch bản.
- Tìm discussionTurn(): thời gian suy nghĩ 1000 ms, gõ 1700 ms.
- Tìm send(): phản hồi giả lập khi người dùng gửi tin.
- Tìm .office, .desk, .cast-member: bố cục văn phòng.
- Tìm chatDialog, openChat(): popup.
- Tìm updateOfficeSpeech(): tin nhắn tại chỗ ngồi.

## Lưu ý phát triển tiếp
Demo có nhiều khối style/script nối tiếp; CSS phía sau ghi đè phía trước. render() được bọc nhiều lớp để cập nhật chat, thảo luận, văn phòng và bong bóng. Giữ thứ tự script khi chưa refactor.
Nếu đưa vào app thật, nên tách Office, EmployeeSeat, ChatDialog, ConversationList và DiscussionDemo cùng state quản lý riêng.
members, portraits và trường who của tin nhắn dùng chung chỉ số. Thêm nhân vật phải cập nhật kịch bản và bố cục; hiện thiết kế cho 4 người.
Tin nhắn chỉ giữ trong bộ nhớ trình duyệt; reload sẽ reset. Không có auth, lưu trữ, realtime, gọi AI, tạo ticket hoặc phân công thật.
Giữ textContent để hiển thị tin nhắn; không dùng innerHTML cho nội dung người dùng.
Gói này không chứa .env, API key, tài khoản hoặc database.

## Kiểm tra trước trình diễn
1. Mở trang thấy 4 bàn và 4 nhân vật, không có studio banner.
2. Xem thảo luận: animation và bong bóng hiện đúng người.
3. Mở popup Tin nhắn xem lịch sử, đóng bằng × hoặc Escape.
4. Dừng giữa chừng không thêm tin kịch bản; Xem lại tạo hội thoại mới.
5. Tạo hội thoại, gửi tin, tìm kiếm và chuyển hội thoại.
6. Kiểm tra mobile 390px và desktop, cuộn tin dài.
7. Bật giảm chuyển động: animation dừng, chức năng vẫn hoạt động.

Đã kiểm tra cú pháp JavaScript và HTTP 200 trong quá trình làm demo. Chưa kiểm thử trình duyệt tự động đầy đủ; cần chạy checklist trên trước nghiệm thu.

Nguồn: nhánh local feat/unified-ui, thư mục demo-chat/. ZIP là bản chụp file hiện tại, không yêu cầu clone repo. Chưa push bản bàn giao lên remote.